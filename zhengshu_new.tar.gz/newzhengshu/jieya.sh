#!/bin/sh
cd /newzhengshu/
rm -rf /shangchuan/*
if [ ! -d /shangchuan ];then mkdir /shangchuan/ ;fi
find /newzhengshu/ -name "*key" |xargs rm -f
find /newzhengshu/ -name "*cer" |xargs rm -f
find /newzhengshu/ -name "*conf" |xargs rm -f
find /newzhengshu/ -name "*zip" |xargs rm -f
tar zxf yuming.tar.gz
rm -rf yuming.tar.gz
sleep 1
b(){
for i  in `ls |grep '\*\|STAR'`;do mv $i xing;done
}
b
sh xing/zhengshu_xing.sh
